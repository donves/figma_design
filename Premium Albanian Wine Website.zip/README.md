
  # Premium Albanian Wine Website

  This is a code bundle for Premium Albanian Wine Website. The original project is available at https://www.figma.com/design/1s4DBsx55loIdKsIgyYNiN/Premium-Albanian-Wine-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  